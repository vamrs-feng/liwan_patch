custom_source_action() {
    git_source https://github.com/radxa/overlays.git b2867b4c753c4a304b847d41f6e8db359953662a
    cp -r $SCRIPT_DIR/.src/overlays/arch $TARGET_DIR
    cp -r 0500-private/. $TARGET_DIR/arch/arm64/boot/dts/rockchip/overlays
}
